using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using System.Windows;

namespace namespace-here
{
    internal class Animations
    {
        static Storyboard storyboard = new Storyboard();
        private static TimeSpan second = TimeSpan.FromSeconds(2);
        private static TimeSpan halfsecond = TimeSpan.FromSeconds(1);

        private static IEasingFunction Smooth
        {
            get;
            set;
        }   
        = new QuarticEase
        {
            EasingMode = EasingMode.EaseOut
        };

        public static void Fade(DependencyObject Object)
        {
            DoubleAnimation FadeIn = new DoubleAnimation()
            {
                From = 0.0,
                To = 1.0,
                Duration = new Duration(halfsecond),
            };
            Storyboard.SetTarget(FadeIn, Object);
            Storyboard.SetTargetProperty(FadeIn, new PropertyPath("Opacity", 1));
            storyboard.Children.Add(FadeIn);
            storyboard.Begin();
        }

        public static void FadeOut(DependencyObject Object)
        {
            DoubleAnimation FadeOut = new DoubleAnimation()
            {
                From = 1.0,
                To = 0.0,
                Duration = new Duration(halfsecond),
            };
            Storyboard.SetTarget(FadeOut, Object);
            Storyboard.SetTargetProperty(FadeOut, new PropertyPath("Opacity", 1));
            storyboard.Children.Add(FadeOut);
            storyboard.Begin();
        }

        public static void Resize(Border MainBorder, int ToHeight, int ToWidth)
        {
            DoubleAnimation danimatioX = new DoubleAnimation();
            danimatioX.From = MainBorder.Width;
            danimatioX.To = ToWidth;
            danimatioX.Duration = second;
            danimatioX.EasingFunction = Smooth;
            MainBorder.BeginAnimation(MainWindow.WidthProperty, danimatioX);

            DoubleAnimation danimatioY = new DoubleAnimation();
            danimatioY.From = MainBorder.Height;
            danimatioY.To = ToHeight;
            danimatioY.Duration = second;
            danimatioY.EasingFunction = Smooth;
            MainBorder.BeginAnimation(MainWindow.HeightProperty, danimatioY);
        }
    }
}
