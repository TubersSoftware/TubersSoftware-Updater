using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Management;

namespace namespace-here
{
    internal class Login
    {
        private static readonly HttpClient client = new HttpClient();
        private static readonly string serverUrl = "railway link here";
        public static string uuid;

        public static void InitializeUUID()
        {
            try
            {
                uuid = GetUUID();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error retrieving UUID: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public static string GetUUID()
        {
            try
            {
                string systemUUID = "";
                using (var searcher = new ManagementObjectSearcher("SELECT UUID FROM Win32_ComputerSystemProduct"))
                {
                    foreach (var obj in searcher.Get())
                    {
                        systemUUID = obj["UUID"]?.ToString();
                        if (!string.IsNullOrEmpty(systemUUID) && systemUUID != "FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF")
                        {
                            return systemUUID;
                        }
                    }
                }

                string uuidFilePath = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "KeySystemWPF", "uuid.txt");
                System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(uuidFilePath));

                if (System.IO.File.Exists(uuidFilePath))
                {
                    return System.IO.File.ReadAllText(uuidFilePath).Trim();
                }

                string newUuid = Guid.NewGuid().ToString();
                System.IO.File.WriteAllText(uuidFilePath, newUuid);
                return newUuid;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error retrieving UUID: ${ex.Message}");
            }
        }

        public static async Task<string> LoginWithUUID(string key)
        {
            try
            {

                if (string.IsNullOrEmpty(key) || string.IsNullOrEmpty(uuid))
                {
                    MessageBox.Show("Key or UUID is empty or null.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return null;
                }

                var requestBody = new { key, uuid };
                string jsonBody = JsonSerializer.Serialize(requestBody);

                var content = new StringContent(
                    jsonBody,
                    Encoding.UTF8,
                    "application/json"
                );

                var response = await client.PostAsync($"{serverUrl}/login", content);
                if (!response.IsSuccessStatusCode)
                {
                    string responseBody = await response.Content.ReadAsStringAsync();
                    var errorResponse = JsonSerializer.Deserialize<LoginResponse>(responseBody);
                    string errorMessage = errorResponse.error ?? $"Unknown error: {response.StatusCode}";
                    MessageBox.Show(errorMessage, "Login Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return null;
                }

                var responseBodySuccess = await response.Content.ReadAsStringAsync();
                var result = JsonSerializer.Deserialize<LoginResponse>(responseBodySuccess);
                return result.key;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error during login: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
        }
    }

    class LoginResponse
    {
        public string key { get; set; }
        public string message { get; set; }
        public string error { get; set; }
    }
}
