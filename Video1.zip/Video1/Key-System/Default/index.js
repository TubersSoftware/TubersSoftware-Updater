const { Client, GatewayIntentBits, REST, Routes } = require('discord.js');
const { Pool } = require('pg');
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const axios = require('axios');
const { v4: uuidv4 } = require('uuid')

const TOKEN = ''; 
const DATABASE_URL = ''; 
const APPLICATION_ID = ''; 
const ADMIN_USER_ID = '';
const GUILD_ID = ''; 

const pool = new Pool({ connectionString: DATABASE_URL, ssl: { rejectUnauthorized: false } });

(async () => {
    try {
        const client = await pool.connect();
        await client.query(`
            CREATE TABLE IF NOT EXISTS registration_keys (
                key TEXT PRIMARY KEY,
                key_type TEXT NOT NULL
            );
        `);
        await client.query(`
            CREATE TABLE IF NOT EXISTS user_keys (
                key TEXT PRIMARY KEY,
                uuid TEXT,
                expires_at TIMESTAMP
            );
        `);
        console.log('Database tables created or verified.');
        client.release();
    } catch (error) {
        console.error('Database setup error:', error.message);
    }
})();

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const commands = [
    {
        name: 'register',
        description: 'Register using a one-time key to receive your unique key.',
        options: [
            {
                name: 'registration-key',
                type: 3, 
                description: 'Your one-time use registration key.',
                required: true
            }
        ]
    },
    {
        name: 'generate-registration-key',
        description: 'Generate a new registration key (admin only).',
        options: [
            {
                name: 'type',
                description: 'The type of key to generate (daily, weekly, monthly, yearly, or lifetime)',
                type: 3, 
                required: true,
                choices: [
                    { name: 'Daily', value: 'daily' },
                    { name: 'Weekly', value: 'weekly' },
                    { name: 'Monthly', value: 'monthly' },
                    { name: 'Yearly', value: 'yearly' },
                    { name: 'Lifetime', value: 'lifetime' }
                ]
            }
        ]
    }
];

const rest = new REST({ version: '10' }).setToken(TOKEN);
(async () => {
    try {
        console.log('Commands to register:', JSON.stringify(commands, null, 2));
        console.log('Clearing existing slash commands for guild...');

        await rest.put(Routes.applicationGuildCommands(APPLICATION_ID, GUILD_ID), { body: [] });
        console.log('Existing guild slash commands cleared.');

        console.log('Registering new slash commands for guild...');
        const result = await rest.put(Routes.applicationGuildCommands(APPLICATION_ID, GUILD_ID), { body: commands });
        console.log('Slash commands registered successfully for guild:', JSON.stringify(result, null, 2));

        console.log('Clearing existing global slash commands...');
        await rest.put(Routes.applicationCommands(APPLICATION_ID), { body: [] });
        console.log('Existing global slash commands cleared.');
    } catch (error) {
        console.error('Error registering commands:', error.message);
        console.error('Error details:', error);
    }
})();

client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
});

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isCommand()) return;
    const { commandName, options, user } = interaction;

    if (commandName === 'register') {
        const regKey = options.getString('registration-key');

        let dbClient;
        try {
            dbClient = await pool.connect();
            await dbClient.query('BEGIN');

            const keyRes = await dbClient.query('SELECT * FROM registration_keys WHERE key = $1', [regKey]);
            if (keyRes.rows.length === 0) {
                await dbClient.query('ROLLBACK');
                await interaction.reply({ content: 'Invalid registration key. Obtain a new one.', ephemeral: true });
                return;
            }

            const keyType = keyRes.rows[0].key_type;

            let expiresAt;
            switch (keyType.toLowerCase()) {
                case 'daily':
                    expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
                    break;
                case 'weekly':
                    expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days
                    break;
                case 'monthly':
                    expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days
                    break;
                case 'yearly':
                    expiresAt = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000); // 365 days
                    break;
                case 'lifetime':
                    expiresAt = null; // No expiration
                    break;
                default:
                    await dbClient.query('ROLLBACK');
                    await interaction.reply({ content: 'Invalid key type in registration key. Contact an administrator.', ephemeral: true });
                    return;
            }

            const newKey = uuidv4();

            const insertQuery = expiresAt
                ? 'INSERT INTO user_keys (key, expires_at) VALUES ($1, $2)'
                : 'INSERT INTO user_keys (key, expires_at) VALUES ($1, NULL)';
            const params = expiresAt ? [newKey, expiresAt] : [newKey];

            await dbClient.query(insertQuery, params);
            await dbClient.query('DELETE FROM registration_keys WHERE key = $1', [regKey]);
            await dbClient.query('COMMIT');

            await user.send(`Your ${keyType} key is: \`${newKey}\``);
            interaction.reply({ content: 'Key generated successfully! Check your DMs for your key.', ephemeral: true });
        } catch (error) {
            if (dbClient) {
                await dbClient.query('ROLLBACK');
            }
            console.error('Registration error:', error.message);
            interaction.reply({ content: 'Failed to generate key. Try again later.', ephemeral: true });
        } finally {
            if (dbClient) {
                dbClient.release();
            }
        }
    }

    if (commandName === 'generate-registration-key') {
        if (user.id !== ADMIN_USER_ID) {
            await interaction.reply({ content: 'You are not authorized to use this command.', ephemeral: true });
            return;
        }

        const keyType = options.getString('type');
        const regKey = `reg-${uuidv4()}`; 

        let dbClient;
        try {
            dbClient = await pool.connect();
            await dbClient.query('BEGIN');

            await dbClient.query(
                'INSERT INTO registration_keys (key, key_type) VALUES ($1, $2)',
                [regKey, keyType.toLowerCase()]
            );

            await dbClient.query('COMMIT');

            await interaction.reply({ content: `Generated registration key: \`${regKey}\` (type: ${keyType})`, ephemeral: true });
        } catch (error) {
            if (dbClient) {
                await dbClient.query('ROLLBACK');
            }
            console.error('Registration key generation error:', error.message);
            interaction.reply({ content: 'Failed to generate registration key. Try again later.', ephemeral: true });
        } finally {
            if (dbClient) {
                dbClient.release();
            }
        }
    }
});

const app = express();
app.use(bodyParser.json());
app.use(cors());

app.post('/login', async (req, res) => {
    const { key, uuid } = req.body;
    if (!key || !uuid) {
        return res.status(400).json({ error: 'Both key and UUID must be provided' });
    }

    let client;
    try {
        client = await pool.connect();
        await client.query('BEGIN');

        const keyRes = await client.query('SELECT * FROM user_keys WHERE key = $1', [key]);
        if (keyRes.rows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(404).json({ error: 'Invalid key. Register via Discord to obtain a valid key.' });
        }

        const keyData = keyRes.rows[0];
        const storedUUID = keyData.uuid;
        const expiresAt = keyData.expires_at;

        if (expiresAt && new Date(expiresAt) < new Date()) {
            await client.query('DELETE FROM user_keys WHERE key = $1', [key]);
            await client.query('COMMIT');

            return res.status(403).json({ error: 'This key has expired and has been deleted. Please register a new key via Discord.' });
        }

        if (!storedUUID) {
            await client.query('UPDATE user_keys SET uuid = $1 WHERE key = $2', [uuid, key]);
            await client.query('COMMIT');

            return res.json({ key, message: 'UUID set successfully. Login successful.' });
        }

        if (storedUUID !== uuid) {
            await client.query('ROLLBACK');
            return res.status(403).json({ error: 'UUID mismatch. This key is already associated with a different device.' });
        }

        await client.query('COMMIT');
        res.json({ key, message: 'Login successful.' });
    } catch (error) {
        if (client) {
            await client.query('ROLLBACK');
        }
        console.error('Login error:', error.message);
        res.status(500).json({ error: 'Internal server error', details: error.message });
    } finally {
        if (client) {
            client.release();
        }
    }
});

app.listen(3000, () => {
    console.log(`Server is running on port 3000`);
});

client.login(TOKEN);